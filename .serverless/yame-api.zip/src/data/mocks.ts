const mocks = {
    String: () => 'Hello World'
};

export default mocks;
